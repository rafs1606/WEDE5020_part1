document.addEventListener("DOMContentLoaded", function () {
  if (!document.body.classList.contains("contact-page")) return;

  const form = document.querySelector(".contact-form");

  form.addEventListener("submit", function (event) {
    event.preventDefault(); 

    const firstName = document.getElementById("firstname").value.trim();
    const email = document.getElementById("email").value.trim();
    const idNumber = document.getElementById("idnumber").value.trim();
    const message = document.getElementById("messagebox").value.trim();

    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if (firstName === "" || email === "" || message === "") {
      alert("Please fill in all required fields.");
      return;
    }

    if (!emailPattern.test(email)) {
      alert("Please enter a valid email address.");
      return;
    }

    if (idNumber.length !== 13 || isNaN(idNumber)) {
      alert("ID number must be 13 digits.");
      return;
    }

    alert("Thank you! Your form has been submitted.");
    form.submit(); 
	console.log("First Name:", firstName);
console.log("Email:", email);
console.log("Message:", message);
  });
})
 document.addEventListener("DOMContentLoaded", function () {
  function updateDateTime() {
    const now = new Date();
    const options = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    };
    document.getElementById('datetime').textContent = now.toLocaleString('en-ZA', options);
  }

  updateDateTime();
  setInterval(updateDateTime, 1000);
});
const images = [
  { src: 'images/dog1.jpeg', caption: 'Simba, Male German Shepherd, 2 years old' },
  { src: 'images/cat1.jpeg', caption: 'Lola, Female Tabby cat, 1 year old' },
  { src: 'images/rabbit.jpeg', caption: 'Milo, Male Rabbit, 6 months old' },
  { src: 'images/dog2.jpeg', caption: 'Blue, Female Labrador Mix, 3 years old' },
];

let currentIndex = 0;

function openLightbox(index) {
  currentIndex = index;
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-img');
  const lightboxCaption = document.getElementById('lightbox-caption');

  lightbox.style.display = 'flex';
  lightboxImg.src = images[index].src;
  lightboxImg.alt = images[index].caption;
  lightboxCaption.textContent = images[index].caption;

  document.body.style.overflow = 'hidden'; 
}

function closeLightbox(event) {
  if (event.target.id === 'lightbox' || event.target.classList.contains('close')) {
    const lightbox = document.getElementById('lightbox');
    lightbox.style.display = 'none';
    document.body.style.overflow = 'auto';
  }
}

function changeImage(direction) {
  currentIndex += direction;
  if (currentIndex < 0) currentIndex = images.length - 1;
  if (currentIndex >= images.length) currentIndex = 0;

  const lightboxImg = document.getElementById('lightbox-img');
  const lightboxCaption = document.getElementById('lightbox-caption');

  lightboxImg.src = images[currentIndex].src;
  lightboxImg.alt = images[currentIndex].caption;
  lightboxCaption.textContent = images[currentIndex].caption;
}

document.addEventListener("DOMContentLoaded", function () {
  const hamburger = document.querySelector(".hamburger");
  const navLinks = document.querySelector(".nav-links");

  if (hamburger && navLinks) {
    hamburger.addEventListener("click", function () {
      hamburger.classList.toggle("active");
      navLinks.classList.toggle("open");
    });
  }
});